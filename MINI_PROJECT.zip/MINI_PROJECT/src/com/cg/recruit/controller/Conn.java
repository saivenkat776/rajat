package com.cg.recruit.controller;

import java.sql.*;

public class Conn {

	static Connection c;
	
	public static Connection getCon() throws ClassNotFoundException //HANDLING THE EXCEPTION
	{
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg601","training601");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return c;
	}
}
