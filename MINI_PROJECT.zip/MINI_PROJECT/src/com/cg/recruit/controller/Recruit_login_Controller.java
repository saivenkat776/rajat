package com.cg.recruit.controller;
import javax.servlet.*;
import java.io.IOException;
import java.sql.*;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Recruit_login_Controller extends HttpServlet{


		
	public  void doGet(HttpServletRequest request,HttpServletResponse response) 
			   throws ServletException,IOException
			{
				    RequestDispatcher rd = null;
					String user_id=request.getParameter("username");
					String password=request.getParameter("password");
					String desig = null;
					String p=request.getParameter("price");
					String sql;
					try {
					Conn c=new Conn();
					Connection c1=c.getCon();
					sql="SELECT role from user1 where user_id='"+user_id+"'";
					Statement pst=c1.createStatement();
					int i=pst.executeUpdate(sql);
					ResultSet rs=pst.executeQuery(sql);
					while(rs.next())
					{
						desig=rs.getString(1);
					}
					System.out.println(desig);
					System.out.println(i);
					if (i==1&&desig.equals("rm"))
						{
						rd=request.getRequestDispatcher("/rm.jsp");
						}
					 if(i==1&&desig.equals("rmg"))
						{
						rd=request.getRequestDispatcher("/rmg.jsp");
						
						}
					 if(i==1&&desig.equals("admin"))
					{
						rd=request.getRequestDispatcher("/admin.jsp");
					}
					if(1==0)
					{
						rd=request.getRequestDispatcher("/login_denied.jsp");
					}
					/*else if(i==1&&desig=="admin")
						request.getRequestDispatcher("/admin.jsp");
					else
						request.getRequestDispatcher("/sucess.jsp");*/
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				
						rd.forward(request, response);
				}
}
