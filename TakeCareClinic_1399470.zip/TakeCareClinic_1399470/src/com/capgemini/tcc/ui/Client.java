package com.capgemini.tcc.ui;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import java.sql.*;
import java.util.Scanner;

class WrongInputException extends Exception{  //USER DEFINED EXCEPTION
	
	public String toString()
	{
		return "ERROR - ENTER BETWEEN 1-3";
	}
}
public class Client {
	
	public static void main(String[] args) throws SQLException{	//MAIN CLASS WITH MENU AND HANDLED EXCEPTION 
		int choice;
		System.out.println("TAKE CARE CLINIC :\n1.Add Patient Information\n2.Search Patient by Id\n3.Exit"); //MENU
		Scanner obj=new Scanner(System.in);
		choice=obj.nextInt();
		try {
		if(choice>3||choice<1)
		{
			throw new WrongInputException();
		}
		}
		catch(WrongInputException e)
		{
			System.out.println(e);
		}
		switch(choice)		//SWITCH BASED OPERATIONS WITH EACH CASE HANDLING EXCEPTION INDIVIDUALLY
		{
		case 1:try {		//CASE 1
			PatientBean obj1=new PatientBean();
			PatientDAO obj2=new PatientDAO();
			String name;
			int age;
			String  pno;
			String desc;
			System.out.print("Enter the name of the Patient:");
			name=obj.next();
			System.out.print("Enter Patient age:");
			age=obj.nextInt();
			System.out.print("Enter Patient phone number:");
			pno=obj.next();
			System.out.print("Enter Description:");
			desc=obj.next();
			obj1.setPname(name);
			obj1.setAge(age);
			obj1.setPno(pno);
			obj1.setPdesc(desc);
			int add;
			add=obj2.addPatientDetails(obj1);
			System.out.println("Patient information is stored succesfully for "+add);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		break;
		
		
		case 2:try {  //CASE 2
			PatientDAO obj2=new PatientDAO();
			int id;
			System.out.print("Enter the Patient ID : ");
			id=obj.nextInt();
		    obj2.getPatientDetails(id);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		break;
		
		
		case 3:try {  //CASE 3
			System.out.println("SYSTEM EXITING");
			System.exit(0);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		break;
		}
		obj.close();

	
	}

}
